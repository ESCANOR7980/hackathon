
from flask import Flask, render_template, request, redirect, url_for, flash, session
import json
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Sample user data (in a real app, this would be in a database)
users = {
    'demo@intellidataops.com': {
        'password': 'demo123',
        'name': 'Demo User',
        'documents': [
            {
                'id': 1,
                'name': 'Aadhaar Card',
                'type': 'Identity',
                'uploaded_date': '2024-01-15',
                'size': '2.3 MB'
            },
            {
                'id': 2,
                'name': 'PAN Card',
                'type': 'Identity',
                'uploaded_date': '2024-01-10',
                'size': '1.8 MB'
            },
            {
                'id': 3,
                'name': 'Driving License',
                'type': 'License',
                'uploaded_date': '2024-01-05',
                'size': '3.1 MB'
            }
        ]
    }
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        if email in users and users[email]['password'] == password:
            session['user'] = email
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        name = request.form['name']
        
        if email not in users:
            users[email] = {
                'password': password,
                'name': name,
                'documents': []
            }
            flash('Registration successful! Please login.')
            return redirect(url_for('login'))
        else:
            flash('Email already exists')
    
    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    
    user_data = users[session['user']]
    return render_template('dashboard.html', user=user_data, documents=user_data['documents'])

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if 'user' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        doc_name = request.form['doc_name']
        doc_type = request.form['doc_type']
        
        new_doc = {
            'id': len(users[session['user']]['documents']) + 1,
            'name': doc_name,
            'type': doc_type,
            'uploaded_date': datetime.now().strftime('%Y-%m-%d'),
            'size': '2.1 MB'  # Simulated size
        }
        
        users[session['user']]['documents'].append(new_doc)
        flash('Document uploaded successfully!')
        return redirect(url_for('dashboard'))
    
    return render_template('upload.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
